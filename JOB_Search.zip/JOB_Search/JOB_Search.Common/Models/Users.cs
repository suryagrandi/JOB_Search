﻿using System;
using System.Collections.Generic;

namespace JOB_Search.Common.Models
{
    public partial class Users
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
    }
}
