﻿using System;

namespace JOB_Search.TestCases
{
    public class Class1
    {
    }
}
